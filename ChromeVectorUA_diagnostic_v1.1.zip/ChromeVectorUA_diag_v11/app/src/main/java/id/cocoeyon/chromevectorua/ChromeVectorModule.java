package id.cocoeyon.chromevectorua;

import android.util.Log;

import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

public final class ChromeVectorModule extends XposedModule {
    private static final String TAG = "ChromeVectorUA";

    @Override
    public void onModuleLoaded(XposedModuleInterface.ModuleLoadedParam param) {
        super.onModuleLoaded(param);
        String processName = param.getProcessName();
        log(Log.INFO, TAG, "CALLBACK onModuleLoaded; process=" + processName
                + "; api=" + getApiVersion()
                + "; framework=" + getFrameworkName());
    }

    @Override
    public void onPackageLoaded(XposedModuleInterface.PackageLoadedParam param) {
        super.onPackageLoaded(param);
        log(Log.INFO, TAG, "CALLBACK onPackageLoaded; package=" + param.getPackageName()
                + "; first=" + param.isFirstPackage());
    }

    @Override
    public void onPackageReady(XposedModuleInterface.PackageReadyParam param) {
        super.onPackageReady(param);
        log(Log.INFO, TAG, "CALLBACK onPackageReady; package=" + param.getPackageName());
    }
}
