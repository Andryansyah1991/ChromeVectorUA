# ChromeVectorUA Diagnostic 1.1

This build is a diagnostic-only libxposed API 102 module scoped to `com.android.chrome`.
It does not modify User-Agent or Client Hints.

It writes Xposed framework log entries with tag `ChromeVectorUA` from:
- `onModuleLoaded` (process name, runtime API and framework name)
- `onPackageLoaded` (package name and first-package flag)
- `onPackageReady` (package name)

## Build
Use JDK 17 and Gradle 8.7 with Android Gradle Plugin 8.6.1, or use the included GitHub Actions workflow.
