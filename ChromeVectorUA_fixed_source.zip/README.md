# ChromeVectorUA

A minimal diagnostic module project for Vector / modern libxposed API 102.

## Build
The GitHub Actions workflow extracts this archive into a clean directory and
runs `gradle assembleDebug` using Gradle 8.7 and JDK 17.

## Current functionality
This is a diagnostic starter only. It initializes the Xposed module and logs
that initialization occurred. It does **not** spoof Chrome's User-Agent,
User-Agent Client Hints, Android build properties, or other Chromium metadata.

Native Chromium hooking requires separate reverse-engineering and validation.
