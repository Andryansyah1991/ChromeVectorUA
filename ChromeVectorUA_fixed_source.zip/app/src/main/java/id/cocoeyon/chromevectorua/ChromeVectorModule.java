package id.cocoeyon.chromevectorua;

import io.github.libxposed.api.XposedModule;

/**
 * Diagnostic entry point only.
 * This module currently does not change Chrome User-Agent or Client Hints.
 */
public final class ChromeVectorModule extends XposedModule {
    @Override
    public void onModuleLoaded() {
        super.onModuleLoaded();
        log("ChromeVectorUA diagnostic module initialized");
    }
}
