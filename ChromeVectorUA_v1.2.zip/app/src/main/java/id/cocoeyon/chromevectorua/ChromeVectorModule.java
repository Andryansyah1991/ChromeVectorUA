package id.cocoeyon.chromevectorua;

import android.util.Log;
import java.security.SecureRandom;
import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

/**
 * ChromeVectorUA 1.2
 *
 * Selects exactly one UA/OS profile per Chrome process.
 * IMPORTANT: This version establishes process-stable profile selection and
 * diagnostic output only. It does NOT yet intercept Chromium's native
 * User-Agent or Client Hints generation paths.
 */
public final class ChromeVectorModule extends XposedModule {
    private static final String TAG = "ChromeVectorUA";
    private static final SecureRandom RNG = new SecureRandom();

    private static final Profile[] PROFILES = new Profile[] {
        new Profile("Android 13", "13.0.0",
            "Mozilla/5.0 (Linux; Android 13; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36"),
        new Profile("Android 14", "14.0.0",
            "Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36"),
        new Profile("Android 15", "15.0.0",
            "Mozilla/5.0 (Linux; Android 15; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36")
    };

    // A fresh classloader/process gets a fresh static field and therefore a
    // new selection. All callbacks within that process reuse this same object.
    private static volatile Profile activeProfile;

    @Override
    public void onModuleLoaded(XposedModuleInterface.ModuleLoadedParam param) {
        super.onModuleLoaded(param);
        String process = param.getProcessName();
        if (process != null && process.startsWith("com.android.chrome")) {
            activeProfile = PROFILES[RNG.nextInt(PROFILES.length)];
            log(Log.INFO, TAG, "PROFILE_SELECTED"
                + "; process=" + process
                + "; profile=" + activeProfile.name
                + "; platformVersion=" + activeProfile.platformVersion
                + "; ua=" + activeProfile.userAgent
                + "; api=" + getApiVersion()
                + "; framework=" + getFrameworkName());
        }
    }

    @Override
    public void onPackageLoaded(XposedModuleInterface.PackageLoadedParam param) {
        super.onPackageLoaded(param);
        if ("com.android.chrome".equals(param.getPackageName())) {
            log(Log.INFO, TAG, "PACKAGE_LOADED; package=" + param.getPackageName()
                + "; first=" + param.isFirstPackage()
                + "; profile=" + profileName());
        }
    }

    @Override
    public void onPackageReady(XposedModuleInterface.PackageReadyParam param) {
        super.onPackageReady(param);
        if ("com.android.chrome".equals(param.getPackageName())) {
            Profile p = activeProfile;
            log(Log.INFO, TAG, "PACKAGE_READY; package=" + param.getPackageName()
                + "; profile=" + profileName()
                + "; nativeHook=NOT_IMPLEMENTED"
                + "; uaApplied=false"
                + "; clientHintsApplied=false");
        }
    }

    private static String profileName() {
        Profile p = activeProfile;
        return p == null ? "not-selected" : p.name;
    }

    private static final class Profile {
        final String name;
        final String platformVersion;
        final String userAgent;

        Profile(String name, String platformVersion, String userAgent) {
            this.name = name;
            this.platformVersion = platformVersion;
            this.userAgent = userAgent;
        }
    }
}
