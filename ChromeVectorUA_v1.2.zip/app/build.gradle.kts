plugins {
    id("com.android.application")
}
android {
    namespace = "id.cocoeyon.chromevectorua"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.cocoeyon.chromevectorua"
        minSdk = 26
        targetSdk = 28
        versionCode = 3
        versionName = "1.2"
    }
}
dependencies {
    compileOnly("io.github.libxposed:api:102.0.0")
}
