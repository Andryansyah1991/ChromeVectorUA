# ChromeVectorUA 1.2

This revision adds one random, process-stable UA/OS profile selection for each
Chrome process start. A force-stop followed by a new process start selects
another profile. The selected profile is reused by all callbacks in that
process.

## Important limitation

This is **not yet a working UA/Client Hints override**. It selects and logs a
profile only. Chrome for Android generates its UA and Client Hints in Chromium
native code; this module does not yet hook those native code paths. The log
explicitly reports `nativeHook=NOT_IMPLEMENTED`, `uaApplied=false`, and
`clientHintsApplied=false` so the diagnostic cannot be mistaken for a
successful browser override.

## Build

Use JDK 17, Gradle 8.7, and Android Gradle Plugin 8.6.1, or run the included
GitHub Actions workflow. Scope: `com.android.chrome`.
