# ChromeVectorUA 1.3.1

## Target

- Android package scope: `com.android.chrome`
- Intended browser test: Chrome 125 (major version 125)
- Candidate profiles: Android 13, 14, 15, and 16
- Candidate platform versions: `13.0.0`, `14.0.0`, `15.0.0`, `16.0.0`

## What this build does

This is a **diagnostic profile selector**, not a browser identity override. Version 1.3.1 fixes the `module.prop` line endings so the API metadata is stored as two valid Java-properties lines.

When a Chrome process loads the module, it randomly selects one profile and
keeps that selection in process-local static state. The selected profile and
candidate Chrome 125 User-Agent are written to the module log.

A new Chrome process gets a new selection. A force-stop followed by a fresh
process start can therefore select a different profile.

## Important limitations

This source does **not** apply the selected values to Chrome. In particular,
it does not:
- change Android system properties or the device's actual OS version;
- hook Chromium's native User-Agent generation;
- change User-Agent Client Hints;
- change the platform version reported by Chrome or websites.

The log intentionally reports:
- `uaApplied=false`
- `clientHintsApplied=false`
- `osValueApplied=false`

Do not interpret `candidateUA` or `PROFILE_SELECTED` as proof that Chrome
actually sent those values. Confirm browser-visible values independently
using a test page or request inspector.

Changing only the User-Agent string would not make Client Hints or other
platform signals consistent. This project does not claim to implement that
more invasive behavior.

## Build

The included GitHub Actions workflow builds a debug APK with JDK 17 and
Gradle 8.7. The APK is a diagnostic Xposed/libxposed module. Its runtime
compatibility depends on the installed framework and its API support.

## Project files

- `ChromeVectorModule.java`: process-local random profile selection and logs
- `META-INF/xposed/scope.list`: Chrome package scope
- `META-INF/xposed/module.prop`: libxposed API metadata
- `.github/workflows/build.yml`: CI build and source checks
