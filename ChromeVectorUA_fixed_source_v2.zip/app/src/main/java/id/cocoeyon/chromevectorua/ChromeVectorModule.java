package id.cocoeyon.chromevectorua;

import android.util.Log;
import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

/** Diagnostic entry point only; does not alter Chrome UA or Client Hints. */
public final class ChromeVectorModule extends XposedModule {
    @Override
    public void onModuleLoaded(XposedModuleInterface.ModuleLoadedParam param) {
        super.onModuleLoaded(param);
        log(Log.INFO, "ChromeVectorUA",
                "Diagnostic module initialized in " + param.getProcessName());
    }
}
