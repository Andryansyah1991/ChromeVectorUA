# ChromeVectorUA

Diagnostic starter project for Vector / libxposed API 102.

Build with JDK 17 and Gradle 8.7 using `gradle assembleDebug`.

This project only initializes the module and logs the process name. It does NOT spoof Chrome User-Agent, User-Agent Client Hints, Android build properties, or other Chromium metadata. Native Chromium hooking requires separate reverse-engineering and validation.
