package id.cocoeyon.chromevectorua;

import android.util.Log;
import java.security.SecureRandom;

import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface;

/**
 * ChromeVectorUA 1.3
 *
 * Diagnostic profile selector for Chrome 125.
 *
 * IMPORTANT:
 * This module selects and logs one profile per Chrome process only.
 * It does not modify Android system properties, Chromium native code,
 * User-Agent, or User-Agent Client Hints. The applied flags are therefore
 * deliberately reported as false.
 */
public final class ChromeVectorModule extends XposedModule {
    private static final String TAG = "ChromeVectorUA";
    private static final String TARGET_PACKAGE = "com.android.chrome";
    private static final String TARGET_CHROME_VERSION = "125";

    private static final SecureRandom RNG = new SecureRandom();

    private static final Profile[] PROFILES = new Profile[] {
        new Profile("Android 13", "13.0.0",
            "Mozilla/5.0 (Linux; Android 13; K) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"),
        new Profile("Android 14", "14.0.0",
            "Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"),
        new Profile("Android 15", "15.0.0",
            "Mozilla/5.0 (Linux; Android 15; K) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"),
        new Profile("Android 16", "16.0.0",
            "Mozilla/5.0 (Linux; Android 16; K) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36")
    };

    /*
     * Static state is process-local. The profile is selected once when the
     * Chrome process loads the module and reused by callbacks in that process.
     */
    private static volatile Profile activeProfile;

    @Override
    public void onModuleLoaded(XposedModuleInterface.ModuleLoadedParam param) {
        super.onModuleLoaded(param);

        String process = param.getProcessName();
        if (process != null && isChromeProcess(process)) {
            activeProfile = PROFILES[RNG.nextInt(PROFILES.length)];
            log(Log.INFO, TAG, "PROFILE_SELECTED"
                + "; process=" + process
                + "; targetChromeMajor=" + TARGET_CHROME_VERSION
                + "; profile=" + activeProfile.name
                + "; platformVersion=" + activeProfile.platformVersion
                + "; candidateUA=" + activeProfile.userAgent
                + "; selection=process-local"
                + "; applied=false"
                + "; api=" + getApiVersion()
                + "; framework=" + getFrameworkName());
        }
    }

    @Override
    public void onPackageLoaded(XposedModuleInterface.PackageLoadedParam param) {
        super.onPackageLoaded(param);

        if (TARGET_PACKAGE.equals(param.getPackageName())) {
            log(Log.INFO, TAG, "PACKAGE_LOADED"
                + "; package=" + param.getPackageName()
                + "; first=" + param.isFirstPackage()
                + "; profile=" + profileName()
                + "; targetChromeMajor=" + TARGET_CHROME_VERSION);
        }
    }

    @Override
    public void onPackageReady(XposedModuleInterface.PackageReadyParam param) {
        super.onPackageReady(param);

        if (TARGET_PACKAGE.equals(param.getPackageName())) {
            Profile profile = activeProfile;
            log(Log.INFO, TAG, "PACKAGE_READY"
                + "; package=" + param.getPackageName()
                + "; profile=" + profileName()
                + "; selected=" + (profile != null)
                + "; uaApplied=false"
                + "; clientHintsApplied=false"
                + "; osValueApplied=false"
                + "; reason=diagnostic-selector-only");
        }
    }

    private static boolean isChromeProcess(String process) {
        return process.equals(TARGET_PACKAGE)
            || process.startsWith(TARGET_PACKAGE + ":");
    }

    private static String profileName() {
        Profile profile = activeProfile;
        return profile == null ? "not-selected" : profile.name;
    }

    private static final class Profile {
        final String name;
        final String platformVersion;
        final String userAgent;

        Profile(String name, String platformVersion, String userAgent) {
            this.name = name;
            this.platformVersion = platformVersion;
            this.userAgent = userAgent;
        }
    }
}
